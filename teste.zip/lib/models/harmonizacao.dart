class Harmonizacao {
  final int id;
  final String descricao;

  Harmonizacao({
    required this.id,
    required this.descricao,
  });
}
